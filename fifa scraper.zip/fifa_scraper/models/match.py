import uuid
from datetime import datetime

from sqlalchemy import DateTime, Index, Integer, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.sql import func

from db.database import Base


class Match(Base):
    __tablename__ = "matches"

    # ------------------------------------------------------------------
    # Primary key
    # ------------------------------------------------------------------
    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
    )

    # ------------------------------------------------------------------
    # Match data
    # ------------------------------------------------------------------
    date: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        index=True,                     # range scans for rolling-window queries
    )
    player_a: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        index=True,                     # per-player stat lookups
    )
    player_b: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        index=True,                     # per-player stat lookups
    )
    goals_a: Mapped[int] = mapped_column(Integer, nullable=False)
    goals_b: Mapped[int] = mapped_column(Integer, nullable=False)

    # Pre-computed at insert time; avoids goals_a + goals_b in every
    # aggregation query (AVG, SUM for Poisson λ estimation).
    total_goals: Mapped[int] = mapped_column(Integer, nullable=False)

    tournament: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # Timestamp set by the database at INSERT; Python never touches it.
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

    # ------------------------------------------------------------------
    # Constraints and indexes
    # ------------------------------------------------------------------
    # Players are always stored sorted (a ≤ b) before insert, so this
    # constraint correctly catches all duplicates regardless of scrape order.
    __table_args__ = (
        UniqueConstraint("player_a", "player_b", "date", name="uq_match_players_date"),
        # Composite index for the two most common analytics joins:
        # "all matches for player X sorted by date"
        Index("ix_matches_player_a_date", "player_a", "date"),
        Index("ix_matches_player_b_date", "player_b", "date"),
    )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def __repr__(self) -> str:
        return (
            f"<Match {self.player_a} {self.goals_a}-{self.goals_b} {self.player_b} "
            f"({self.total_goals} total) @ {self.date.date()}>"
        )

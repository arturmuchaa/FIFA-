# FIFA Valhalla Cup Scraper

A clean async pipeline that scrapes **finished** FIFA matches from
[drafted.gg/valhalla-cup](https://drafted.gg/valhalla-cup) and stores
them in PostgreSQL.

---

## Project Layout

```
fifa_scraper/
├── main.py                        # Entrypoint – run the full pipeline
├── requirements.txt
├── .env.example                   # Copy to .env and fill in credentials
├── alembic.ini
├── alembic/
│   ├── env.py
│   └── versions/                  # Auto-generated migration files
├── db/
│   ├── __init__.py
│   └── database.py                # Engine, session factory, Base
├── models/
│   ├── __init__.py
│   └── match.py                   # Match ORM model
├── services/
│   └── scraper/
│       ├── __init__.py
│       ├── raw_match.py           # Validation dataclass
│       ├── scraper.py             # Playwright scraper
│       └── repository.py          # DB persistence (dedup + insert)
└── tests/
    └── test_validation.py         # Unit tests (no DB/browser needed)
```

---

## Quick Start

### 1 – Prerequisites

| Tool | Version |
|------|---------|
| Python | 3.11+ |
| PostgreSQL | 14+ |
| Node.js | not needed |

### 2 – Install dependencies

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
playwright install chromium
```

### 3 – Configure

```bash
cp .env.example .env
# Edit .env – set DATABASE_URL to your PostgreSQL instance
```

`.env` example:
```
DATABASE_URL=postgresql+asyncpg://postgres:secret@localhost:5432/fifa_matches
TOURNAMENT=valhalla-cup
LOG_LEVEL=INFO
```

### 4 – Create the database

```bash
# Create the DB if it doesn't exist yet
createdb fifa_matches

# (Optional) run Alembic migrations instead of auto-create
alembic upgrade head
```

### 5 – Run

```bash
python main.py
```

Sample output:
```
2024-05-01 21:00:00  INFO      pipeline  Initialising database schema …
2024-05-01 21:00:01  INFO      pipeline  Starting scraper for tournament: valhalla-cup
2024-05-01 21:00:05  INFO      scraper   Navigating to https://drafted.gg/valhalla-cup
2024-05-01 21:00:12  INFO      pipeline  Scraper returned 48 raw match candidates.
2024-05-01 21:00:13  INFO      repository  Inserted: alice 2-1 bob @ 2024-04-28 …
…
2024-05-01 21:00:15  INFO      pipeline  Pipeline complete — inserted: 46  |  skipped/invalid: 2
```

### 6 – Run tests

```bash
pytest tests/ -v
```

---

## Database Schema

```sql
CREATE TABLE matches (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    date        TIMESTAMPTZ NOT NULL,
    player_a    VARCHAR(255) NOT NULL,
    player_b    VARCHAR(255) NOT NULL,
    goals_a     INTEGER NOT NULL,
    goals_b     INTEGER NOT NULL,
    tournament  VARCHAR(255),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),

    CONSTRAINT uq_match_players_date UNIQUE (player_a, player_b, date)
);
```

---

## Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Only finished matches** | Score must be two non-negative integers; rows with `NULL` scores are rejected at the `RawMatch.is_valid()` level. |
| **Duplicate guard** | DB unique constraint + pre-insert `SELECT` check; `IntegrityError` is caught as a safety net for race conditions. |
| **Nested savepoints** | Each row gets its own `begin_nested()` so a failed insert doesn't abort the whole batch. |
| **Name normalisation** | `strip + lower + collapse whitespace` ensures "Alice " and "alice" are treated as the same player. |
| **Playwright `networkidle`** | Waits for the SPA to finish loading before parsing. Falls back to text extraction if the DOM strategy yields nothing. |
| **No ORM relationships** | A single flat table is sufficient; over-engineering avoided. |

---

## Scheduling (Optional)

To run the pipeline on a cron schedule:

```cron
# Every day at 02:00
0 2 * * * /path/to/.venv/bin/python /path/to/fifa_scraper/main.py >> /var/log/fifa_scraper.log 2>&1
```

Or with `systemd`, `supervisor`, or any task scheduler of your choice.

---

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| `asyncpg.exceptions.ConnectionRefusedError` | PostgreSQL not running, or wrong `DATABASE_URL` |
| Scraper returns 0 matches | The site may have changed its DOM – update selectors in `services/scraper/scraper.py` |
| Playwright `TimeoutError` | Slow connection; increase `_PAGE_LOAD_TIMEOUT` in `scraper.py` |
| `alembic.util.exc.CommandError` | Run `alembic revision --autogenerate -m "init"` to create the first migration |

"""
Unit tests – no DB or browser required.

Run with:  pytest tests/
"""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from services.scraper.raw_match import RawMatch
from services.scraper.scraper import _parse_date_string


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _dt(year=2024, month=5, day=1, hour=20) -> datetime:
    return datetime(year, month, day, hour, 0, tzinfo=timezone.utc)


def _valid_raw(**overrides) -> RawMatch:
    defaults = dict(
        player_a="Alice",
        player_b="Bob",
        goals_a=2,
        goals_b=1,
        date=_dt(),
        tournament="valhalla-cup",
        match_id="alice_bob_2024-05-01T20:00:00+00:00",
    )
    defaults.update(overrides)
    return RawMatch(**defaults)


# ---------------------------------------------------------------------------
# RawMatch validation
# ---------------------------------------------------------------------------

def test_valid_match_passes():
    assert _valid_raw().is_valid() is True


def test_missing_player_a():
    assert _valid_raw(player_a="").is_valid() is False


def test_missing_player_b():
    assert _valid_raw(player_b="  ").is_valid() is False


def test_none_goals_a():
    assert _valid_raw(goals_a=None).is_valid() is False


def test_none_goals_b():
    assert _valid_raw(goals_b=None).is_valid() is False


def test_negative_goals():
    assert _valid_raw(goals_a=-1).is_valid() is False


def test_missing_date_is_invalid():
    """A match with no date must be rejected – no datetime.now() fallback."""
    assert _valid_raw(date=None).is_valid() is False


def test_zero_zero_is_valid():
    """A 0-0 draw is a legitimate finished result."""
    assert _valid_raw(goals_a=0, goals_b=0).is_valid() is True


# ---------------------------------------------------------------------------
# match_id
# ---------------------------------------------------------------------------

def test_match_id_stored_on_raw_match():
    raw = _valid_raw(match_id="alice_bob_2024-05-01T20:00:00+00:00")
    assert raw.match_id == "alice_bob_2024-05-01T20:00:00+00:00"


def test_normalized_preserves_match_id():
    raw = _valid_raw(match_id="alice_bob_2024-05-01T20:00:00+00:00")
    norm = raw.normalized()
    assert norm.match_id == "alice_bob_2024-05-01T20:00:00+00:00"


def test_normalized_generates_match_id_when_absent():
    """If match_id is None, normalized() must compute one from normalised names + date."""
    raw = _valid_raw(player_a="Alice", player_b="Bob", match_id=None)
    norm = raw.normalized()
    assert norm.match_id is not None
    assert norm.match_id.startswith("alice_bob_")


# ---------------------------------------------------------------------------
# Name normalisation
# ---------------------------------------------------------------------------

def test_normalize_trims_spaces():
    raw = _valid_raw(player_a="  Alice  ", player_b="  Bob  ")
    norm = raw.normalized()
    assert norm.player_a == "alice"
    assert norm.player_b == "bob"


def test_normalize_lowercases():
    raw = _valid_raw(player_a="ALICE", player_b="BOB")
    norm = raw.normalized()
    assert norm.player_a == "alice"
    assert norm.player_b == "bob"


def test_normalize_collapses_whitespace():
    raw = _valid_raw(player_a="alice   smith", player_b="bob")
    norm = raw.normalized()
    assert norm.player_a == "alice smith"


def test_normalize_name_static():
    assert RawMatch.normalize_name("  JOHN  DOE  ") == "john doe"


# ---------------------------------------------------------------------------
# In-memory deduplication key (tuple shape)
# ---------------------------------------------------------------------------

def test_dedup_key_uniqueness():
    """Same player/score/date → identical dedup key."""
    r1 = _valid_raw()
    r2 = _valid_raw()
    key1 = (r1.player_a, r1.player_b, r1.goals_a, r1.goals_b, r1.date)
    key2 = (r2.player_a, r2.player_b, r2.goals_a, r2.goals_b, r2.date)
    assert key1 == key2


def test_dedup_key_differs_on_score():
    r1 = _valid_raw(goals_a=2)
    r2 = _valid_raw(goals_a=3)
    key1 = (r1.player_a, r1.player_b, r1.goals_a, r1.goals_b, r1.date)
    key2 = (r2.player_a, r2.player_b, r2.goals_a, r2.goals_b, r2.date)
    assert key1 != key2


# ---------------------------------------------------------------------------
# Sorting
# ---------------------------------------------------------------------------

def test_sort_by_date_ascending():
    matches = [
        _valid_raw(date=_dt(day=3)),
        _valid_raw(date=_dt(day=1)),
        _valid_raw(date=_dt(day=2)),
    ]
    matches.sort(key=lambda m: m.date)
    assert [m.date.day for m in matches] == [1, 2, 3]


# ---------------------------------------------------------------------------
# Date parsing
# ---------------------------------------------------------------------------

def test_parse_date_iso_with_tz():
    dt = _parse_date_string("2024-05-01T20:00:00+00:00")
    assert dt is not None
    assert dt.year == 2024 and dt.month == 5 and dt.day == 1


def test_parse_date_iso_no_tz_becomes_utc():
    dt = _parse_date_string("2024-03-15 18:30:00")
    assert dt is not None
    assert dt.tzinfo is not None


def test_parse_date_plain_date():
    dt = _parse_date_string("2024-03-15")
    assert dt is not None
    assert dt.year == 2024 and dt.month == 3 and dt.day == 15


def test_parse_date_unix_timestamp():
    dt = _parse_date_string("1714593600")   # 2024-05-02 00:00 UTC
    assert dt is not None
    assert dt.year == 2024


def test_parse_date_returns_none_for_garbage():
    assert _parse_date_string("not-a-date") is None


def test_parse_date_rejects_zero_timestamp():
    """Timestamp 0 (epoch) should not be treated as a valid match date."""
    assert _parse_date_string("0") is None

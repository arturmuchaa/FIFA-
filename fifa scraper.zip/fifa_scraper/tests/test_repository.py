"""
Unit tests for MatchRepository helpers.
No database connection required – _build_rows is pure Python.

Run with:  pytest tests/
"""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from services.scraper.raw_match import RawMatch
from services.scraper.repository import _build_rows


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _dt(day: int = 1) -> datetime:
    return datetime(2024, 5, day, 20, 0, tzinfo=timezone.utc)


def _raw(player_a="alice", player_b="bob", goals_a=2, goals_b=1,
         date=None, **kw) -> RawMatch:
    return RawMatch(
        player_a=player_a,
        player_b=player_b,
        goals_a=goals_a,
        goals_b=goals_b,
        date=date or _dt(),
        tournament="valhalla-cup",
        **kw,
    )


# ---------------------------------------------------------------------------
# _build_rows – valid input
# ---------------------------------------------------------------------------

def test_valid_match_produces_one_row():
    rows = _build_rows([_raw()])
    assert len(rows) == 1


def test_row_contains_required_keys():
    row = _build_rows([_raw()])[0]
    for key in ("id", "date", "player_a", "player_b", "goals_a", "goals_b",
                "total_goals", "tournament"):
        assert key in row


def test_created_at_not_in_row():
    """created_at must be absent – the DB server_default owns it."""
    row = _build_rows([_raw()])[0]
    assert "created_at" not in row


def test_total_goals_is_sum():
    row = _build_rows([_raw(goals_a=3, goals_b=2)])[0]
    assert row["total_goals"] == 5


def test_total_goals_zero_zero():
    row = _build_rows([_raw(goals_a=0, goals_b=0)])[0]
    assert row["total_goals"] == 0


def test_total_goals_after_player_swap():
    """total_goals must be consistent regardless of player sort order."""
    row = _build_rows([_raw(player_a="zeus", player_b="alice", goals_a=3, goals_b=1)])[0]
    assert row["total_goals"] == 4


def test_id_is_uuid():
    import uuid
    row = _build_rows([_raw()])[0]
    assert isinstance(row["id"], uuid.UUID)


# ---------------------------------------------------------------------------
# Player sorting
# ---------------------------------------------------------------------------

def test_players_stored_in_sorted_order():
    row = _build_rows([_raw(player_a="zeus", player_b="alice")])[0]
    assert row["player_a"] == "alice"
    assert row["player_b"] == "zeus"


def test_goals_swapped_with_players():
    """When player order is swapped, goals must follow their player."""
    # zeus=3 goals, alice=1 goal; after sort alice is player_a
    row = _build_rows([_raw(player_a="zeus", player_b="alice", goals_a=3, goals_b=1)])[0]
    assert row["player_a"] == "alice"
    assert row["goals_a"] == 1   # alice's goals
    assert row["player_b"] == "zeus"
    assert row["goals_b"] == 3   # zeus's goals


def test_already_sorted_players_unchanged():
    row = _build_rows([_raw(player_a="alice", player_b="zeus", goals_a=2, goals_b=0)])[0]
    assert row["player_a"] == "alice"
    assert row["goals_a"] == 2
    assert row["player_b"] == "zeus"
    assert row["goals_b"] == 0


# ---------------------------------------------------------------------------
# Name normalisation (via RawMatch.normalized())
# ---------------------------------------------------------------------------

def test_names_are_lowercased():
    row = _build_rows([_raw(player_a="ALICE", player_b="BOB")])[0]
    assert row["player_a"] == "alice"
    assert row["player_b"] == "bob"


def test_names_are_stripped():
    row = _build_rows([_raw(player_a="  alice  ", player_b="  bob  ")])[0]
    assert row["player_a"] == "alice"
    assert row["player_b"] == "bob"


# ---------------------------------------------------------------------------
# Invalid rows are dropped
# ---------------------------------------------------------------------------

def test_missing_date_dropped():
    rows = _build_rows([_raw(date=None)])
    assert rows == []


def test_missing_player_dropped():
    rows = _build_rows([_raw(player_a="")])
    assert rows == []


def test_negative_goals_dropped():
    rows = _build_rows([_raw(goals_a=-1)])
    assert rows == []


def test_none_goals_dropped():
    rows = _build_rows([_raw(goals_a=None)])
    assert rows == []


# ---------------------------------------------------------------------------
# Mixed batch
# ---------------------------------------------------------------------------

def test_mixed_batch_keeps_valid_only():
    valid = _raw(player_a="alice", player_b="bob", date=_dt(1))
    invalid = _raw(player_a="", player_b="bob", date=_dt(2))
    rows = _build_rows([valid, invalid])
    assert len(rows) == 1
    assert rows[0]["player_a"] == "alice"


def test_multiple_valid_rows():
    matches = [_raw(player_a="alice", player_b=f"player{i}", date=_dt(i + 1))
               for i in range(5)]
    rows = _build_rows(matches)
    assert len(rows) == 5


def test_each_row_gets_unique_id():
    matches = [_raw(player_a="alice", player_b=f"p{i}", date=_dt(i + 1))
               for i in range(3)]
    rows = _build_rows(matches)
    ids = [r["id"] for r in rows]
    assert len(set(ids)) == 3  # all distinct

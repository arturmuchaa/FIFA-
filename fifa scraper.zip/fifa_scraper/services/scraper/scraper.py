"""
Scraper for https://drafted.gg/valhalla-cup

Rules (strict – no exceptions)
-------------------------------
- DOM extraction only. If it yields nothing → return [].
- Date is mandatory. A card without a parseable date is silently dropped.
- datetime.now() is NEVER used as a fallback.
- In-memory deduplication via a set keyed on
  (player_a, player_b, goals_a, goals_b, date).
- Every match carries a deterministic match_id:
  f"{player_a}_{player_b}_{date.isoformat()}"
- Results are returned sorted by date ascending.
"""

from __future__ import annotations

import asyncio
import logging
import re
from datetime import datetime, timezone

from playwright.async_api import Page, async_playwright, TimeoutError as PWTimeout

from services.scraper.raw_match import RawMatch

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
BASE_URL = "https://drafted.gg/valhalla-cup"
_PAGE_LOAD_TIMEOUT = 30_000   # ms
_TAB_WAIT = 1.5               # seconds after clicking a navigation tab

# Candidate selectors for match card containers.
# Order matters: more specific selectors are tried first.
_CARD_SELECTOR = (
    "[class*='matchRow'],[class*='match-row'],[class*='MatchRow'],"
    "[class*='gameRow'],[class*='game-row'],[class*='GameRow'],"
    "article[class*='match'],article[class*='game'],"
    "[class*='match'],[class*='Match'],[class*='game'],[class*='Game'],"
    "[class*='result'],[class*='Result']"
)

_PLAYER_SELECTOR = (
    "[class*='player'],[class*='Player'],"
    "[class*='username'],[class*='Username'],"
    "[class*='team'],[class*='Team'],"
    "[class*='name'],[class*='Name']"
)

# Regex: score like  "2 - 1" / "2:1" / "2–1"
_SCORE_RE = re.compile(r"(\d{1,2})\s*[-:–]\s*(\d{1,2})")

# Regex: ISO-8601 substring inside card text
_ISO_DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}")

_DATE_FORMATS = [
    "%Y-%m-%dT%H:%M:%S%z",
    "%Y-%m-%dT%H:%M:%S.%f%z",
    "%Y-%m-%dT%H:%M%z",
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%d %H:%M",
    "%Y-%m-%d",
    "%d/%m/%Y %H:%M",
    "%d.%m.%Y %H:%M",
    "%d.%m.%Y",
]


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

async def scrape_matches(tournament: str = "valhalla-cup") -> list[RawMatch]:
    """
    Launch a headless browser, scrape drafted.gg, and return a validated,
    deduplicated list of RawMatch objects sorted by date ascending.

    Returns an empty list on any unrecoverable error – never raises.
    """
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True)
        context = await browser.new_context(
            viewport={"width": 1280, "height": 900},
            user_agent=(
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
            ),
        )
        page = await context.new_page()
        try:
            matches = await _scrape_page(page, tournament)
        except Exception as exc:
            logger.error("Scraping failed: %s", exc, exc_info=True)
            matches = []
        finally:
            await browser.close()

    return matches


# ---------------------------------------------------------------------------
# Page-level orchestration
# ---------------------------------------------------------------------------

async def _scrape_page(page: Page, tournament: str) -> list[RawMatch]:
    logger.info("Navigating to %s", BASE_URL)
    await page.goto(BASE_URL, wait_until="networkidle", timeout=_PAGE_LOAD_TIMEOUT)
    await asyncio.sleep(2)  # let the SPA finish hydrating

    await _try_click_results_tab(page)

    logger.debug("Page HTML size: %d bytes", len(await page.content()))

    matches = await _extract_from_dom(page, tournament)

    if not matches:
        logger.warning("DOM extraction yielded no valid matches – returning empty list.")
        return []

    logger.info("Returning %d validated, deduplicated matches.", len(matches))
    return matches


async def _try_click_results_tab(page: Page) -> None:
    """Click the 'Results' / 'Past' / 'Finished' tab when present."""
    for label in ("results", "past", "finished", "history", "completed"):
        pattern = re.compile(label, re.IGNORECASE)
        for role in ("button", "link"):
            try:
                locator = page.get_by_role(role, name=pattern)  # type: ignore[arg-type]
                if await locator.count() > 0:
                    await locator.first.click()
                    await asyncio.sleep(_TAB_WAIT)
                    logger.info("Navigated via %s tab: '%s'", role, label)
                    return
            except PWTimeout:
                continue
            except Exception as exc:
                logger.debug("Tab click skipped (%s / %s): %s", role, label, exc)


# ---------------------------------------------------------------------------
# DOM extraction
# ---------------------------------------------------------------------------

async def _extract_from_dom(page: Page, tournament: str) -> list[RawMatch]:
    """
    Walk candidate card elements and collect only fully-valid matches.
    Applies in-memory deduplication before returning.
    """
    cards = await page.query_selector_all(_CARD_SELECTOR)
    logger.debug("Found %d candidate card elements", len(cards))

    seen: set[tuple] = set()
    matches: list[RawMatch] = []

    for card in cards:
        try:
            raw = await _parse_card(card, tournament)
        except Exception as exc:
            logger.debug("Card parse error (skipped): %s", exc)
            continue

        if raw is None:
            continue  # missing date, score, or players

        dedup_key = (raw.player_a, raw.player_b, raw.goals_a, raw.goals_b, raw.date)
        if dedup_key in seen:
            logger.debug("Duplicate skipped: %s", dedup_key)
            continue

        seen.add(dedup_key)
        matches.append(raw)

    # Sort ascending by date before handing off to the repository
    matches.sort(key=lambda m: m.date)  # type: ignore[arg-type]
    return matches


async def _parse_card(card, tournament: str) -> RawMatch | None:
    """
    Parse one match card.

    Returns None (and logs the reason) for any of:
    - no score found
    - fewer than two distinct player names found
    - date cannot be extracted
    """
    text = (await card.inner_text()).strip()

    # ── Score ──────────────────────────────────────────────────────────────
    score_m = _SCORE_RE.search(text)
    if not score_m:
        return None

    goals_a = int(score_m.group(1))
    goals_b = int(score_m.group(2))

    # ── Players ────────────────────────────────────────────────────────────
    players = await _extract_players(card, text, score_m)
    if len(players) < 2:
        logger.debug("Skipping card – could not find two players. text=%r", text[:120])
        return None

    player_a, player_b = players[0], players[1]

    # ── Date (mandatory – no fallback) ─────────────────────────────────────
    date = await _extract_date(card)
    if date is None:
        logger.debug(
            "Skipping card – no parseable date. players=%s vs %s", player_a, player_b
        )
        return None

    # ── Build match_id ─────────────────────────────────────────────────────
    norm_a = RawMatch.normalize_name(player_a)
    norm_b = RawMatch.normalize_name(player_b)
    match_id = f"{norm_a}_{norm_b}_{date.isoformat()}"

    return RawMatch(
        player_a=player_a,
        player_b=player_b,
        goals_a=goals_a,
        goals_b=goals_b,
        date=date,
        tournament=tournament,
        match_id=match_id,
    )


async def _extract_players(card, full_text: str, score_m: re.Match) -> list[str]:
    """
    Try structured child elements first, then positional text splitting
    around the score – but only if both tokens are non-numeric.
    """
    # Strategy 1: dedicated player / username elements
    player_els = await card.query_selector_all(_PLAYER_SELECTOR)
    names: list[str] = []
    for el in player_els:
        name = (await el.inner_text()).strip()
        if name and not re.fullmatch(r"[\d\s:–\-]+", name):
            names.append(name)
        if len(names) == 2:
            return names

    # Strategy 2: positional split around the score
    before = full_text[: score_m.start()].strip()
    after = full_text[score_m.end() :].strip()

    tokens_before = [t for t in re.split(r"\s{2,}|\n", before) if t.strip()]
    tokens_after = [t for t in re.split(r"\s{2,}|\n", after) if t.strip()]

    cand_a = tokens_before[-1].strip() if tokens_before else ""
    cand_b = tokens_after[0].strip() if tokens_after else ""

    # Reject if either candidate looks like a pure number / date fragment
    if (
        cand_a and cand_b
        and not re.fullmatch(r"[\d\s:–\-/]+", cand_a)
        and not re.fullmatch(r"[\d\s:–\-/]+", cand_b)
    ):
        return [cand_a, cand_b]

    return names  # may be empty – caller will drop the card


async def _extract_date(card) -> datetime | None:
    """
    Try every structured date source in priority order.
    Returns a timezone-aware UTC datetime, or None if nothing parseable found.
    Never falls back to datetime.now().
    """
    # 1. <time datetime="…">
    time_el = await card.query_selector("time")
    if time_el:
        dt_attr = await time_el.get_attribute("datetime")
        if dt_attr:
            result = _parse_date_string(dt_attr)
            if result:
                return result
        inner = (await time_el.inner_text()).strip()
        if inner:
            result = _parse_date_string(inner)
            if result:
                return result

    # 2. data-date / data-timestamp / data-time attributes
    for attr in ("data-date", "data-timestamp", "data-time"):
        el = await card.query_selector(f"[{attr}]")
        if el:
            val = await el.get_attribute(attr)
            if val:
                result = _parse_date_string(val)
                if result:
                    return result

    # 3. ISO-8601 substring anywhere in the card text
    card_text = await card.inner_text()
    iso_m = _ISO_DATE_RE.search(card_text)
    if iso_m:
        result = _parse_date_string(iso_m.group(0))
        if result:
            return result

    # No date found – caller must drop this card
    return None


# ---------------------------------------------------------------------------
# Date parsing
# ---------------------------------------------------------------------------

def _parse_date_string(s: str) -> datetime | None:
    """
    Try a fixed list of formats plus unix-timestamp.
    Returns a UTC-aware datetime, or None on failure.
    """
    s = s.strip()

    for fmt in _DATE_FORMATS:
        try:
            dt = datetime.strptime(s, fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except ValueError:
            continue

    # Unix timestamp (integer or float)
    try:
        ts = float(s)
        if 0 < ts < 9_999_999_999:  # sanity-check: year range ~1970-2286
            return datetime.fromtimestamp(ts, tz=timezone.utc)
    except ValueError:
        pass

    return None

"""
Repository: validate → normalise → batch-upsert match records.

Design
------
- All valid matches are inserted in a single round-trip using
  PostgreSQL "INSERT … ON CONFLICT DO NOTHING".
- No pre-insert SELECT queries (eliminates N read RTTs).
- No per-row commits (one transaction for the entire batch).
- Players are always stored in ascending alphabetical order so the
  unique constraint (player_a, player_b, date) fires correctly
  regardless of which side scraped as "home".
- created_at is handled by the DB default (server_default=now()).
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone

from sqlalchemy import insert
from sqlalchemy.ext.asyncio import AsyncSession

from models.match import Match
from services.scraper.raw_match import RawMatch

logger = logging.getLogger(__name__)


class MatchRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def save_many(self, raw_matches: list[RawMatch]) -> tuple[int, int]:
        """
        Validate, normalise, and batch-insert a list of RawMatch objects.

        Duplicates are silently ignored at the database level via
        ON CONFLICT DO NOTHING on the (player_a, player_b, date) constraint.

        Returns
        -------
        (attempted, skipped_invalid) — 'attempted' is the count sent to
        the DB; actual inserts vs. conflicts are resolved server-side.
        """
        rows = _build_rows(raw_matches)

        invalid = len(raw_matches) - len(rows)
        if invalid:
            logger.warning("%d invalid match(es) skipped before insert.", invalid)

        if not rows:
            logger.info("No valid matches to insert.")
            return 0, invalid

        try:
            await self._batch_upsert(rows)
        except Exception as exc:
            logger.error("Batch insert failed, transaction rolled back: %s", exc, exc_info=True)
            await self._session.rollback()
            return 0, len(raw_matches)

        logger.info("Batch of %d match(es) sent to DB (conflicts silently ignored).", len(rows))
        return len(rows), invalid

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _batch_upsert(self, rows: list[dict]) -> None:
        """
        Execute a single INSERT … ON CONFLICT DO NOTHING for all rows.
        Commits once after the statement completes.
        """
        stmt = (
            insert(Match)
            .values(rows)
            .on_conflict_do_nothing(
                index_elements=["player_a", "player_b", "date"],
            )
        )
        await self._session.execute(stmt)
        await self._session.commit()


# ------------------------------------------------------------------
# Pure helper – no I/O
# ------------------------------------------------------------------

def _build_rows(raw_matches: list[RawMatch]) -> list[dict]:
    """
    Validate and normalise each RawMatch into an insert-ready dict.

    - Names are lowercased and whitespace-collapsed.
    - Players are sorted alphabetically (a ≤ b) so the unique constraint
      is orientation-agnostic.
    - Rows with missing/invalid fields are dropped and logged.
    """
    rows: list[dict] = []

    for raw in raw_matches:
        norm = raw.normalized()

        if not norm.is_valid():
            logger.warning(
                "Dropped invalid match: player_a=%r player_b=%r goals=%s-%s date=%s",
                raw.player_a, raw.player_b, raw.goals_a, raw.goals_b, raw.date,
            )
            continue

        # Guarantee consistent player ordering for the unique constraint
        player_a, player_b = sorted([norm.player_a, norm.player_b])
        goals_a, goals_b = (
            (norm.goals_a, norm.goals_b)
            if norm.player_a == player_a
            else (norm.goals_b, norm.goals_a)
        )

        rows.append(
            {
                "id": uuid.uuid4(),
                "date": norm.date,
                "player_a": player_a,
                "player_b": player_b,
                "goals_a": goals_a,
                "goals_b": goals_b,
                "total_goals": goals_a + goals_b,
                "tournament": norm.tournament,
                # created_at intentionally omitted – handled by server_default
            }
        )

    return rows

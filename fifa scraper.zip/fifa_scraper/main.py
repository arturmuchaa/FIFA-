"""
Main entrypoint for the FIFA / Valhalla Cup scraper pipeline.

Usage
-----
    python main.py

Environment variables (see .env.example):
    DATABASE_URL   – asyncpg connection string
    TOURNAMENT     – label stored in the `tournament` column (default: valhalla-cup)
    LOG_LEVEL      – Python logging level (default: INFO)
"""

from __future__ import annotations

import asyncio
import logging
import os
import sys

from dotenv import load_dotenv

load_dotenv()

# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.INFO),
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    stream=sys.stdout,
)
logger = logging.getLogger("pipeline")

# ---------------------------------------------------------------------------
# Project imports (after logging is configured)
# ---------------------------------------------------------------------------
from db import init_db, AsyncSessionFactory            # noqa: E402
from services.scraper import scrape_matches            # noqa: E402
from services.scraper.repository import MatchRepository  # noqa: E402


async def run_pipeline() -> None:
    tournament = os.getenv("TOURNAMENT", "valhalla-cup")

    # 1. Initialise DB schema
    logger.info("Initialising database schema …")
    await init_db()

    # 2. Scrape
    logger.info("Starting scraper for tournament: %s", tournament)
    try:
        raw_matches = await scrape_matches(tournament=tournament)
    except Exception as exc:
        logger.error("Scraper raised an unhandled exception: %s", exc, exc_info=True)
        raw_matches = []

    if not raw_matches:
        logger.warning("Scraper returned no matches. Exiting.")
        return

    logger.info("Scraper returned %d raw match candidates.", len(raw_matches))

    # 3. Persist
    async with AsyncSessionFactory() as session:
        repo = MatchRepository(session)
        inserted, skipped = await repo.save_many(raw_matches)

    logger.info(
        "Pipeline complete — inserted: %d  |  skipped/invalid: %d", inserted, skipped
    )


def main() -> None:
    asyncio.run(run_pipeline())


if __name__ == "__main__":
    main()
